class PostsController < ApplicationController
  def index
    @content_1="I am a part of sample post 1"
    @content_2="I am a part of sample post 2"
  end
  def new

  end
  def create

  end
  def edit

  end
  def update

  end
  def show

  end
  def destroy

  end
end
